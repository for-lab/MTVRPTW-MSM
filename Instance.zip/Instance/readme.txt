The files Solomon_1, Solomon_2 and Solomon_3 represent the instances with 1, 2 and 3 types of staff, respectively. 

staff_0: the lowest skill level staff
staff_2: the highest skill level staff